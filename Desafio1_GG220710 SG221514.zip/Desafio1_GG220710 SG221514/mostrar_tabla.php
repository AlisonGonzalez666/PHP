<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tablas de equivalencias</title>
    <link rel="stylesheet" href="style.css"/>
</head>
</html>

<?php

$factores = array(
    "longitud" => array(
        "metros" => 1,
        "pulgadas" => 39.37,
        "pies" => 3.281,
        "yardas" => 1.094
    ),
    "volumen" => array(
        "metros_cubicos" => 1,
        "mililitros" => 1000000,
        "litros" => 1000,
        "galón" => 264.172
    )
);

function generarTabla($tipo) {
    global $factores;
    $tabla = "<table border='1'>";
    $tabla .= "<tr><th>{$tipo}</th>";
    foreach ($factores[$tipo] as $unidad => $factor) {
        $tabla .= "<th>{$unidad}</th>";
    }
    $tabla .= "</tr>";
    
    
    for ($i = 0.25; $i <= 1.50; $i += 0.25) {
        $tabla .= "<tr><td>{$i}</td>";
        foreach ($factores[$tipo] as $unidad => $factor) {
            $tabla .= "<td>" . ($i * $factor) . "</td>";
        }
        $tabla .= "</tr>";
    }
    
    $tabla .= "</table>";
    return $tabla;
}


if (isset($_GET['tipo'])) {
    $tipo = $_GET['tipo'];
    echo generarTabla($tipo);
} else {
    echo "Seleccione una tabla.";
}
?>